# InsightAI – Student Outcome Predictor
Run locally: `pip install -r requirements.txt && python app.py` → http://127.0.0.1:5000
Render start command: `gunicorn app:app`
Keep `logistic.pkl` in the same folder as `app.py` (or set env var MODEL_PATH).
